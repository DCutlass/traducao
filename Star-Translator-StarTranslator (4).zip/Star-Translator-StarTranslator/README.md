# Star-Translator 🌎
 This repository is a comically broken creation of a updater for SC Localization
 
 ![Javatpoint](https://pa1.aminoapps.com/7556/290db318026cf9d2f2bb3b9c817b06c127a873b4r1-300-300_00.gif)

This Cockroach repo work as a update file location for 'Star Translator' to download and install! 